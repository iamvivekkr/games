const jwt = require("jsonwebtoken")
const User = require("../Model/User")

const Auth = async (req, res, next) => {
    try {
        //   var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
        //   console.log(fullUrl,'fullUrl')
          
            let ip =req.get('origin');
     const clientIP = req.headers['x-forwarded-for']?.split(',').shift() || req.socket?.remoteAddress;
    //  console.log(clientIP,'clientIP')
    ip = ip.toString().replace('::ffff:', '');
if(  ip != 'https://staradda.in' && ip != 'https://www.staradda.in' && ip != 'https://panel.staradda.in'  && ip != 'http://localhost:4044' && ip != 'http://localhost:4022' ){
     return next(
                res.status(401).send({status:false,msg:"pls loginn"})
            )
}
// console.log(ip)
var token = '';
        token = req.header("Authorization").replace("Bearer ", "")
        if (!token) {
            throw new Error()
        } else{
            if(token != "null" || !token){
              
              const decoded = jwt.verify(token, "soyal")
        const user = await User.findOne({ _id: decoded._id, "tokens.token": token })

        if (!user) {
          res.status(401).send({status:false,msg:"pls login"})
        }
        

        req.token = token

        req.user = user
        next()
            }else{
                 res.status(401).send({status:false,msg:"pls login"})
            }
        }
      

    } catch (e) {
        console.log(e,'error')
        res.status(401).send({status:false,msg:"pls loginn"})
    }

}

module.exports = Auth